#!/bin/bash

function paus(){
	echo
	read -p "$*"
	echo
}

clear

echo >> info.small.txt
echo "Före paccache -rk 5" > info.small.txt
echo >> info.small.txt

#sudo df -h | head -1 >> info.small.txt
sudo df -h | tail -n +2 |  sort -n -k1 | grep /dev/sda >> info.small.txt

paus "Tar bort äldre versioner. Tryck enter!"

sudo paccache -rk 5

paus "Klart. Tryck enter!"

clear

echo >> info.small.txt
echo "Efter paccache -rk 5"  >> info.small.txt
echo >> info.small.txt

sudo df -h | tail -n +2 |  sort -n -k1 | grep /dev/sda >> info.small.txt

# sudo df -h | head -1 && sudo df -h | tail -n +2 |  sort -n -k1 | grep /dev/sda >> info.small.txt

echo >> info.small.txt

cat info.small.txt


if [ -f "info.sh" ]
then
	echo
	./info.sh
fi 


