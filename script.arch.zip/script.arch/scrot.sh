#!/bin/bash

scrot '%Y-%m-%d-%H:%M_$wx$h.png' -q 100 -d 5 -c -e mv $f ~/Bilder/ #  ger en bild som heter 2015-01-24-15:37_3840x1080.png
