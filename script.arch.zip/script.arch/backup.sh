#!/bin/bash

############################################
## Skapa en backupkatalog i $HOME         ##
############################################
sudo mkdir -p $HOME/.backup

############################################
## Backup av viktiga fier                 ##
############################################
sudo cp /etc/pacman.conf $HOME/.backup/pacman.conf-$(date +%Y%m%d)
sudo cp /etc/fstab $HOME/.backup/fstab-$(date +%Y%m%d)
sudo cp /etc/vconsole.conf $HOME/.backup/vconsole.conf-$(date +%Y%m%d)

##
## sudo cp $HOME/.pyradio/stations.csv $HOME/.backup/stations.csv-$(date +%Y%m%d)
##
