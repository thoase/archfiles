#!/bin/bash
function paus(){
	echo
	read -p "$*"
	echo
}

clear

trizen -Syyu ## --aur

if [ -f "info.sh" ]
then
	paus "Uppdateringen klar. Tryck enter!"
	./info.sh
fi 

## 
## Problem med
## ==> Verifying source file signatures with gpg...
## cower-7.tar.gz ... FAILED (unknown public key 1EB2638FF56C0C53)
## ==> WARNING: Warnings have occurred while verifying the signatures.
##     Please make sure you really trust them. 
##
## Löses genom kommandot
## gpg --recv-key <key nummer>
##
## enligt https://bbs.archlinux.org/viewtopic.php?id=152337
##
