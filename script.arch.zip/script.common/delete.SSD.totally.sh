#!/bin/bash

echo


# dd if=/dev/zero of/dev/sda bs=8M status=progress
