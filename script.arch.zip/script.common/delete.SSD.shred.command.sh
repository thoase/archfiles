#!/bin/bash

pacman -S coreutils 

# The following command invokes shred with its default settings and displays the progress.
# By default shred uses three passes

# shred -v /dev/sda
