#!/bin/bash

sh whatsmyip.sh

echo "Stoppar protonvpn"
sudo systemctl stop openvpn-client@protonvpn.service

sh whatsmyip.sh

