#!/bin/bash

sh whatsmyip.sh 

echo "Startar protonvpn"
sudo systemctl start openvpn-client@protonvpn.service

echo

./countdown.sh

echo

./whatsmyip.sh 
