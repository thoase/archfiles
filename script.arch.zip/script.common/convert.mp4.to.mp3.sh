#!/bin/bash

# Orginal:

# MP4FILE=$(ls ~/Music/ |grep .mp4)
# for filename in $MP4FILE
# do 
#  name=`echo "$filename" | sed -e "s/.mp4$//g"`
#  ffmpeg -i ~/Music/$filename -b:a 192K -vn ~/Music/$name.mp3
# done


MP4FILE=$(ls /media/sde1/Youtube/U2/ |grep .mp4)
for filename in $MP4FILE
do 
 name=`echo "$filename" | sed -e "s/.mp4$//g"`
 ffmpeg -i /media/sde1/Youtube/U2/$filename -b:a 192K -vn /media/sde1/Youtube/U2/$name.mp3
done
