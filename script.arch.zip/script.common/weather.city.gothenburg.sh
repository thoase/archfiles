#/bin/bash

#!/bin/sh

URL='https://www.accuweather.com/sv/se/goteborg/315909/weather-forecast/315909'

wget -q -O- "$URL" | awk -F\' '/acm_RecentLocationsCarousel\.push/{print $2": "$16", "$12"°" }'| head -1
