#!/bin/bash
clear

if [ "$1" ]; then
        pyradio -s /home/$USER/.pyradio/sveriges.radio.csv
else
        pyradio -s /home/$USER/.pyradio/stations.csv
fi
## pyradio -s /home/thomas/.pyradio/lokalradio.csv
