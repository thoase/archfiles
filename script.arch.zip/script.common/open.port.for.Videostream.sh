#!/bin/bash

sudo /sbin/iptables -A INPUT -p tcp --dport 5556 -j ACCEPT
sudo /sbin/iptables -A INPUT -p tcp --dport 5558 -j ACCEPT

