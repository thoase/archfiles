#!/bin/bash

# First obtain a location code from: https://weather.codes/search/

# Insert your location code. For example 
# LOXX0001	Bratislava, Slovakia
# SWXX0033	Sundsvall, Sweden
# SWXX0007	Gothenburg, Sweden

location=$1

# Obtain sunrise and sunset raw data from weather.com
# sun_times=$( lynx --dump  https://weather.com/weather/today/l/$location | grep "\* Sun" | sed "s/[[:alpha:]]//g;s/*//" )

# Alternative curl/wget solution. In case you wish to use curl or wget instead of lynx comment the above line and uncomment one of the lines below:
# sun_times=$( curl -s  https://weather.com/weather/today/l/$location | sed 's/<span/\n/g' | sed 's/<\/span>/\n/g'  | grep -E "dp0-details-sunrise|dp0-details-sunset" | tr -d '\n' | sed 's/>/ /g' | cut -d " " -f 4,8 )
# sun_times=$( wget -qO-  https://weather.com/weather/today/l/$location | sed 's/<span/\n/g' | sed 's/<\/span>/\n/g'  | grep -E "dp0-details-sunrise|dp0-details-sunset" | tr -d '\n' | sed 's/>/ /g' | cut -d " " -f 4,8 )

# Extract sunrise and sunset times and convert to 24 hour format
# sunrise=$(date --date="`echo $sun_times | awk '{ print $1}'` AM" +%R)
# sunset=$(date --date="`echo $sun_times | awk '{ print $2}'` PM" +%R)

sun_times=($( wget -qO- https://weather.com/weather/today/l/$location | sed 's/ /\n/g' | sed -n '/p0-details-sunrise\|dp0-details-sunset/s/[^>]*>//p' ))

# Extract sunrise and sunset times and convert to 24 hour format
sunrise=$(date --date="${sun_times[0]} AM" +%R)
sunset=$(date --date="${sun_times[1]} PM" +%R)

# Use $sunrise and $sunset variables to fit your needs. Example:
echo "Soluppgång: $sunrise	Solnedgång: $sunset"


