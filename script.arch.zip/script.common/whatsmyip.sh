#!/bin/bash

IP=$(wget --timeout=30 http://ipinfo.io/ip -qO -)

echo

echo "Current ip: " $IP # wget --timeout=30 http://ipinfo.io/ip -qO -

echo

geoiplookup $IP

echo

