#/bin/bash

echo

URL='https://www.accuweather.com/sv/se/sundsvall/315848/weather-forecast/315848'

wget -q -O- "$URL" | awk -F\' '/acm_RecentLocationsCarousel\.push/{print $2": "$16", "$12"°" }'| head -1
