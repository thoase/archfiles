#!/bin/bash

echo

alsi 

