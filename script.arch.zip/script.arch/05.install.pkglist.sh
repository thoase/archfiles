#!/bin/bash

./00.update.pacman.sh

##########################################################################################
##
## https://wiki.archlinux.org/index.php/Pacman/Tips_and_tricks#List_of_installed_packages
## Kommando för att plocka fram alla installerade AUR-program; 
## pacman -Qqem > filename.of.aur.programs.txt
##
##########################################################################################

pacman -S --needed - < pkglist.txt

