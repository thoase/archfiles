#!/bin/bash

echo

lsblk -d -o name,rota

echo
echo ROTA means rotational device, 1 if true, 0 if false = SSD
echo
