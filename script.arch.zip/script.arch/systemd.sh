#!/bin/bash

echo
echo "systemd-analyze $(systemd-analyze)"
echo

echo "systemd-analyze blame"
systemd-analyze blame | head -10
echo


