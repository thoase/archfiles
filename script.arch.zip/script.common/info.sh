#!/bin/bash

sudo clear
echo
# echo "Kernel $(uname -r)"
echo

##  df -h
sudo df -h | head -1 && sudo df -h | tail -n +2 |  sort -n -k1   
echo
free -m

echo

pydf

if [ -f "alsi.sh" ]
then
	./alsi.sh
fi 

exit


if [ -f "systemd.sh" ]
then
	./systemd.sh
fi 

exit 

echo
echo "systemd-analyze $(systemd-analyze)"
echo

echo "systemd-analyze blame"
systemd-analyze blame | head -10
echo


