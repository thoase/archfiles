#!/bin/bash

sudo git clone https://aur.archlinux.org/trizen.git
cd trizen
sudo makepkg -si

