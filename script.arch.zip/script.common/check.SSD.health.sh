#!/bin/bash

##
## How to check SSD health in Linux
##
## The smartctl utility is a part of the smartmontools package.
##
## Ubuntu:	sudo apt install smartmontools
## Arch:	trizen -S smartmontools
## 

clear 
echo
sudo smartctl -i /dev/sda
sudo smartctl -t short -a /dev/sda > ssd.testinfo.short-$(date +%Y%m%d).txt
sudo smartctl -t long -a /dev/sda > ssd.testinfo.long-$(date +%Y%m%d).txt
echo

