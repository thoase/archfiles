#!/bin/bash

function paus(){
	echo
	read -p "$*"
	echo
}

## Bärbar med touchpad? 
## sudo pacman -Sy xf86-input-synaptics

## sudo pacman -Sy gedit vlc nemo alsa-utils pulseaudio  pulseaudio-equalizer volumeicon pavucontrol python flashplugin zsh zsh-completions hplip simple-scan  gthumb evince cups cups-pdf fbreader transmission-gtk gnome-screenshot calibre chromium firefox midori

## Terminal
## sudo pacman -Sy tmux moc scrot ranger glances ffmpeg openssh yaourt wget w3m python freedns-daemon unrar youtube-dl calc poppler unzip bmon 

## paus "Installera trådlöst"
## sudo pacman -S iw wpa_supplicant dialog wireless_tools wpa_actiond network-manager-applet ##  wicd

## Allt på en gång
trizen -Sy gedit vlc nemo alsa-utils pulseaudio pulseaudio-equalizer volumeicon pavucontrol python flashplugin zsh zsh-completions hplip simple-scan gthumb evince cups cups-pdf fbreader transmission-gtk gnome-screenshot calibre tmux moc scrot ranger glances ffmpeg openssh yaourt wget w3m python freedns-daemon unrar youtube-dl calc poppler unzip bmon iw wpa_supplicant dialog wireless_tools wpa_actiond network-manager-applet ncdu pacman-contrib


paus "Installera AUR-program, men först trizen"

sudo git clone https://aur.archlinux.org/trizen.git
cd trizen
sudo makepkg -si

trizen -S alsi preload cower-git ffmpeg-full-extra pydf chromium-pepper-flash pepper-flash chromium-widevine rar speedtest-cli svtplay-dl spotify hplip-plugin tkpacman xed-git  pamac-aur pyradio-git inxi glxinfo sl gnu-cobol opencobolide irssi gradio



##################################################################
##								##
## Bärbar med touchpad? 					##
##								##
##################################################################
# paus ‘Bärbar med touchpad?‘
trizen -Sy xf86-input-synaptics

## Några andra webbrowser
## trizen -S yandex-browser-beta slimjet brave ##  iridium inox

## Add public key for tor-browser
## gpg --recv-keys D1483FA6C3C07136
## trizen -S tor-browser

###################################################################################################################
## Glöm inte att byta ut 'rw,relatime,data=ordered' i fstab mot 'defaults,noatime,discard' för ssd-partitionerna.
###################################################################################################################

