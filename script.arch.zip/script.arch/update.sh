#!/bin/bash
function paus(){
	echo
	read -p "$*"
	echo
}

clear

sudo pacman -Syyu

if [ -f "info.sh" ]
then
	paus "Uppdateringen klar. Tryck enter!"
	./info.sh
fi 

#exit
#if [ -f "trim.sh" ]
#then
#	./trim.sh
#fi


# Remove orphaned packages. First do a pacman query -Q for all dependencies -d that are unrequired -t.
# sudo pacman -Qdt

# If you have unrequired dependencies, why not remove them. This simple 
# command with recursively remove all unrequired dependencies.
# pacman -Rs $(pacman -Qtdq)

# Similar to CCleaner on Windows, BleachBit clears out temp files, system 
# caches, and other junk. You can find it here in the AUR 
# Bleachit: https://aur.archlinux.org/packages.php?ID=36043

