#/bin/bash

curl wttr.in/Moon

