#/bin/bash

function paus(){
	echo
	read -p "$*"
	echo
}

clear

sudo pacman -Rs $(pacman -Qtdq)

if [ -f "info.sh" ]
then
	paus "Uppdateringen klar. Tryck enter!"
	./info.sh
fi 



