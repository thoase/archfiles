#!/bin/bash
clear
scrot '%Y-%m-%d-%H:%M_$wx$h.png' -q 100 -d 5 -c -e 'mv $f ~/Bilder'
