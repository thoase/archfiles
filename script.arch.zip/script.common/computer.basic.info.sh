#!/bin/bash

clear 

echo

inxi -c 5 -b

echo

