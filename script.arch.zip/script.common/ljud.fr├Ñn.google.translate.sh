#!/bin/bash

#wget -q -U Mozilla -O sv.mp3 "http://translate.google.com/translate_tts?ie=UTF-8&tl=sv&q=Klockan är fem i åtta. "  #; mplayer sv.mp3

#wget -q -U Mozilla -O 5min.mp3 "http://translate.google.com/translate_tts?ie=UTF-8&tl=sv&q=Dags att avsluta! om fem minuter stängs datorn av"; mplayer 5min.mp3

# Skicka påminnelse
mplayer femiåtta.mp3 5min.mp3

sleep 270

#wget -q -U Mozilla -O 30sek.mp3 "http://translate.google.com/translate_tts?ie=UTF-8&tl=sv&q=30 sekunder kvar"; mplayer 30sek.mp3

mplayer 30sek.mp3

sleep 30

mplayer Thunder-Crash-02.mp3
