#!/bin/bash

function paus(){
	echo
	read -p "$*"
	echo
}


##################################################################
##								##
## Först en uppdatering                                         ##
##								##
##################################################################
sudo pacman -Syu

paus "Installera AUR-program, men först trizen"

sudo git clone https://aur.archlinux.org/trizen.git
cd trizen
sudo makepkg -si
# yaourt -S trizen

paus ‘Finns pacman.conf? Kopiera det isf till /etc/”
if [ -f "pacman.conf" ]
then
	sudo cp pacman.conf /etc/.
fi

##################################################################
##								##
## Det grafiska							##
##								##
##################################################################
paus ‘Installera det grafiska xorg-server xorg-server-utils xf86-video-nouveau xf86-input-evdev xf86-input-mouse xorg-xinit xorg-server-xephyr mesa ’
#sudo pacman -Syu xorg-server xorg-server-utils xf86-video-nouveau xf86-input-evdev xf86-input-mouse xorg-xinit xorg-server-xephyr mesa 
trizen -Syu xorg-server xorg-server-utils xf86-video-nouveau xf86-input-evdev xf86-input-mouse xorg-xinit xorg-server-xephyr mesa 

##################################################################
##								##
## alternativt nvidia drivers:					##
## sudo pacman -S nvidia nvidia-libgl lib32-nvidia-libgl 	##
## lib32-nvidia-utils						##
##								##
##################################################################

##################################################################
##								##
## Bärbar med touchpad? 					##
##								##
##################################################################
# paus ‘Bärbar med touchpad?‘
trizen -Syu xf86-input-synaptics

##################################################################
##								##
## Display manager						##
##								##
##################################################################
paus ‘Installera display- och windowmanager lightdm enlightenment cinnamon’
# sudo pacman -Sy gdm 
trizen  -Syu lightdm  enlightenment cinnamon

## sudo pacman -S gnome gnome-extra
## sudo systemctl enable gdm.service
## sudo pacman -S gnome-tweak-tool
## yaourt -S gnome-software


paus "Installera trådlöst"
trizen -S iw wpa_supplicant dialog wireless_tools wpa_actiond network-manager-applet ##  wicd

## Allt på en gång
trizen -Sy gedit vlc nemo alsa-utils pulseaudio pulseaudio-equalizer volumeicon pavucontrol python flashplugin zsh zsh-completions hplip simple-scan gthumb evince cups cups-pdf fbreader transmission-gtk gnome-screenshot calibre tmux moc scrot ranger glances ffmpeg openssh wget w3m python freedns-daemon unrar youtube-dl calc poppler unzip bmon iw wpa_supplicant dialog wireless_tools wpa_actiond network-manager-applet ncdu pacman-contrib gnome-terminal gcalcli rsync

trizen -S alsi preload cower-git ffmpeg-full-extra pydf chromium-pepper-flash pepper-flash chromium-widevine rar speedtest-cli svtplay-dl spotify hplip-plugin tkpacman xed-git pamac-aur pyradio-git inxi glxinfo sl gnu-cobol opencobolide irssi gradio

####################################################################
##                                                                ##
## Window manager                                                 ##
##								##
##################################################################
## sudo pacman -Sy xfce4 xfce4-goodies xfce4-whiskermenu-plugin
#sudo pacman -Sy enlightenment cinnamon 
## sudo pacman -Sy mate mate-extra  marco mate-panel mate-session-manager

####################################################################
##                                                                ##
## Program                                                        ##
##                                                                ##
## evince 	pdfläsare					  ##
## fbreader	simple EPUB reader				  ##
## kodi		multimedia player				  ##
##								##
##################################################################
paus ‘Installera grafiska program’

# sudo pacman -Sy gedit vlc nemo alsa-utils pulseaudio  pulseaudio-equalizer pavucontrol python flashplugin gthumb hplip cups cups-pdf simple-scan evince fbreader transmission-gtk gnome-screenshot gnome-terminal terminology calibre chromium firefox midori 

## lxterminal, kodi zsh zsh-completions

####################################################################
##                                                                ##
## Terminalprogram                                                ##
##                                                                ##
## poppler för pdftotext					  ##
## calc - kalkylator						  ##
## speedtest-cli - hastighetskoll				  ##
## bmon - Monitor Linux System Performance			  ##
## pdfgrep - A tool to search text in PDF files			  ##
##								##
##################################################################
#echo ‘Installera terminalprogram’
#sudo pacman -Sy tmux moc scrot ranger glances ffmpeg openssh yaourt wget w3m python freedns-daemon unrar youtube-dl svtplay-dl calc poppler unzip bmon googler-git

## samba gcalcli rsync newsbeuter

## installerar rtorrent-color istället för rtorrent
## htop, behövs ej i och med att glances är med


####################################################################
##                                                                ##
## Wireless                                                       ##
## wiki.archlinux.org/index.php/Beginners'_guide#Wired            ##
##                                                                ##
## Wireless network configuration                                 ##
## wiki.archlinux.org/index.php/Wireless_network_configuration    ##
##                                                                ##
## Wicd is a network connection manager that can manage wireless  ##
## and wired interfaces.					  ##
## https://wiki.archlinux.org/index.php/Wicd 			  ##
##								##
##################################################################
#paus ‘Installera trådlöst'
echo
trizen -Syu iw wpa_supplicant dialog wireless_tools wpa_actiond network-manager-applet ##  wicd

####################################################################
##                                                                ##
## Connman is a command-line network manager       		  ##
##                                                                ##
## Econnman — Enlightenment desktop panel applet.		  ##
## http://www.enlightenment.org econnmanAUR			  ##
##                                                                ##
## cmst — Qt GUI for ConnMan                                      ##
##								##
## The bluez package provides the Bluetooth protocol stack, and the bluez-utils package provides the bluetoothctl utility.
##
## Load the generic bluetooth driver, if not already loaded:
## modprobe btusb
##
## Then start the bluetooth.service systemd unit. You can enable it to start automatically at boot time.
##
##################################################################
## sudo pacman -Sy connman bluez  bluez-utils 
trizen -Syu cmst bluez  bluez-utils 

####################################################################
##                                                                ##
## The Samba server is configured in /etc/samba/smb.conf.default. ##
## Copy the default configuration file to /etc/samba/smb.conf     ##
##								##
##################################################################
# cp /etc/samba/smb.conf.default /etc/samba/smb.conf


####################################################################
##                                                                ##
## Lägg till shares i smb.conf                                    ##
##								##
##################################################################
## if [ -f "samba.shares.txt" ]
## then
## 	# Backup
## 	sudo cp /etc/samba/smb.conf $HOME/.backup/smb.conf-$(date +%Y%m%d)
## 	# Kopiera
## 	sudo cat samba.shares.txt >> /etc/samba/smb.conf
## fi

####################################################################
##                                                                ##
## Rätt tangentbord? Annars kika här				  ##
## https://bbs.archlinux.org/viewtopic.php?id=215544 		  ##
##								##
##################################################################
if [ -f "keyboard.conf" ]
then
	echo
	paus 'Kopiera keyboard.conf för rätt tangentbord'
	echo

	## https://bbs.archlinux.org/viewtopic.php?id=215544
	sudo cp keyboard.conf /etc/X11/xorg.conf.d/.
fi 

####################################################################
##                                                                ##
## Installera AUR-program     ##
##								##
## chromium-widevine för Netflix				##
## sconsify, spotify i terminalen, 
##								##
##################################################################
paus ‘Installera AUR-program’

trizen -S alsi pyradio-git preload cower-git ffmpeg-full pepper-flash profile-sync-daemon rar speedtest-cli chromium-widevine  spotify sconsify hplip-plugin svtplay-dl vivaldi vivaldi-ffmpeg-codecs 

## mutt-sidebar zsh-syntax-highlighting-git rtorrent-color


######################################################
## Musikspelaren clementine och alla dess beroenden ##
######################################################
## yaourt -Sy clementine gstreamer0.10-base-plugins gstreamer0.10-ugly-plugins gstreamer0.10-bad-plugins gstreamer0.10-good-plugins  gnome-video-effects gst-plugins-bad gst-plugins-base  
## gst-plugins-base-libs gst-plugins-good gstreamer  gstreamer0.10  gstreamer0.10-bad gstreamer0.10-bad-plugins  gstreamer0.10-base  gstreamer0.10-base-plugins  gstreamer0.10-good  gstreamer0.10-good-plugins  
## gstreamer0.10-ugly gstreamer0.10-ugly-plugins totem

paus 'Kopiera filer(om de finns) fstab.extra.txt stations.csv xinitrc ' 

####################################################################
##                                                                ##
## Lägg till mount av de övriga diskarna i fstab. Kolla även hur  ##
## /etc/fstab ser ut.                                             ##
## Glöm inte att byta ut 'rw,relatime,data=ordered' i fstab mot   ##
## 'defaults,noatime,discard' för ssd-partitionerna.              ##
##								##
##################################################################
if [ -f "fstab.extra.txt" ]
then
	## sudo cat fstab.extra.txt >> /etc/fstab
	sudo nano /etc/fstab
fi 

####################################################################
##                                                                ##
## Kopiera stations.csv till $HOME/.pyradio               	  ##
##								##
##################################################################
if [ -f "stations.csv" ]
then
	if [ ! -d "$HOME/.pyradio" ]; 
	then
		sudo mkdir $HOME/.pyradio
	fi 

	sudo cp stations.csv $HOME/.pyradio/.
fi 

####################################################################
##                                                                ##
## Kopiera xinitrc  till $HOME/.xinitrc                        ##
##								##
##################################################################
if [ -f "xinitrc" ]
then
	sudo cp xinitrc $HOME/.xinitrc
fi 
##################################################################
##								##
## Kopiera bashrc till $HOME/.bashrc				##
##								##
##################################################################
if [ -f "bashrc" ]
then
	sudo cp bashrc $HOME/.bashrc
fi 

####################################################################
##                                                                ##
## Starta services                                                ##
##								##
##################################################################

paus ‘Starta services lightdm preload sshd cups’

## gdm eller lightdm
sudo systemctl start lightdm.service
sudo systemctl enable lightdm.service

## sudo systemctl start gdm.service
## sudo systemctl enable gdm.service

## samba
# sudo systemctl start smbd.service
# sudo systemctl enable smbd.service
# sudo systemctl start nmbd.service
# sudo systemctl enable nmbd.service

## preload
sudo systemctl start preload.service
sudo systemctl enable preload.service

## ssh
sudo systemctl start sshd.service
sudo systemctl enable sshd.service

## cups
#sudo systemctl start org.cups.cupsd.service
#sudo systemctl enable org.cups.cupsd.service

## connman
## sudo systemctl start connman.service
## sudo systemctl enable connman.service

####################################################################
##                                                                ##
## Klart!!                                                        ##
##								##
##################################################################
echo
echo Klart!
echo
echo Glöm inte att byta ut 'rw,relatime,data=ordered' i fstab mot 'defaults,noatime,discard' för ssd-partitionerna.
echo


###########################################################################################################
##                                                                                                       ##
## Lite noteringar:                                                                                      ## 
##                                                                                                       ##
## - pulseaudio-equalizer: https://wiki.archlinux.org/index.php/PulseAudio#Equalizer                     ##
## - wpa_supplicant is a cross-platform supplicant with support for WEP, WPA and                         ##
##	WPA2 (IEEE 802.11i / RSN (Robust Secure Network)).                                               ##
##	It is suitable for desktops, laptops and embedded systems.                                       ##
## - Finns detta pgm: hp-toolbox??                                                                       ##
## - Profile-sync-daemon: https://wiki.archlinux.org/index.php/profile-sync-daemon                       ##
## - Info om freedns-daemon, kolla https://plus.google.com/u/0/115458345216688998068/posts/YBWARPZHZuv   ##
##                                                                                                       ##
###########################################################################################################

## Behövs dessa?
## python2-reportlab 
## python2-notify 
## rpcbind 
## python2-pyqt4 
## python2-gobject2 
## python2-gobject2 

## Ändra i /etc/vconsole.conf. Lägg till FONT=lat9w-16, så att å, ä och ö finns med. Börja med en backup.
## sudo cp /etc/vconsole.conf $HOME/.backup/vconsole.conf-$(date "+%Y-%m-%d-%T")
## raden 'FONT=Lat2-Terminus16' ska kommenteras
## sudo sed -e 's/^FONT$/#FONT/' /etc/vconsole.conf 
## sudo echo "FONT=lat9w-16" >> /etc/vconsole.conf
## sudo cp vconsole.conf /etc/.

## Terminalprogram
## - iptraf-ng A console-based network monitoring utility (a fork of original iptraf)
## - bmon Portable bandwidth monitor and rate estimator
## - hddtemp is a small utility (with daemon) that gives the hard-drive temperature via S.M.A.R.T. (for drives supporting this feature).
## - bwm-ng A small and simple console-based live bandwidth monitor
## - pdfgrep A tool to search text in PDF files
##
##
## iptraf bmon hddtemp bwm-ng nmap ipcalc speedtest-cli 

## https://wiki.archlinux.org/index.php/Hddtemp

## wavemon - Övervakning av trådlöst nätverk, signalstyrka, brus m.m
## speedtest-cli test hastigheten

## Glöm inte att byta ut 'rw,relatime,data=ordered' i fstab mot 'defaults,noatime,discard' för ssd-partitionerna.


