#!/bin/bash

cd /home/$USER

mkdir Bilder/ Dokument/ Dropbox/ Hämtningar/ Musik/ Skrivbord/ Video/


