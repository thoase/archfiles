#!/bin/bash

echo

echo "Enable av protonvpn.service"
sudo systemctl enable openvpn-client@protonvpn.service

echo

