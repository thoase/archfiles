#!/bin/bash

clear
echo
sudo iwlist scan | grep ESSID

