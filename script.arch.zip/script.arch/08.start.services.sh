#!/bin/bash

# gdm
# sudo systemctl start gdm.service
# sudo systemctl enable gdm.service

# lightdm
sudo systemctl start lightdm.service
sudo systemctl enable lightdm.service

# preload
sudo systemctl start preload.service
sudo systemctl enable preload.service

exit

# samba
sudo systemctl start smbd.service
sudo systemctl enable smbd.service
sudo systemctl start nmbd.service
sudo systemctl enable nmbd.service

# ssh
sudo systemctl start sshd.service
sudo systemctl enable sshd.service

