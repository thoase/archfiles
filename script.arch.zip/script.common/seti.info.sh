#!/bin/bash

clear
echo
boinccmd --get_simple_gui_info > seti.info.txt
#pluma seti.info.txt&
exit

head -22 seti.info.txt
echo
tail -22 seti.info.txt
echo
