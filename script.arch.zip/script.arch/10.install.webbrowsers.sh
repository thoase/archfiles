#!/bin/bash

function paus(){
	echo
	read -p "$*"
	echo
}


##################################################################
##								##
## Först en uppdatering                                         ##
##								##
##################################################################
./00.update.pacman.sh

##sudo pacman -Syu

## https://wiki.archlinux.org/index.php/List_of_applications#Web_browsers

## Add public key for tor-browser
gpg --recv-keys D1483FA6C3C07136

trizen -S firefox chromium seamonkey opera vivaldi epiphany tor-browser midori opera vivaldi

##
###############################################################################################################################################################
##
## A lot of webbrowsers
## trizen -S firefox chromium seamonkey opera google-chrome 

## trizen -R cyberfox-bin waterfox-bin inox-bin slimjet tor-browser google-chrome crusta dooble falkon konqueror liri-browser-git qtwebbrowser qutebrowser min brave-bin eolie epiphany lariza luakit  poseidon surf surferuzbl-browser vimb eric ospkit-git otter-browser qutebrowser smtube wcgbrowser-git netsurf palemoon-bin min 

## falkon konqueror  qutebrowser min brave-bin eolie eric ospkit-git otter-browser qutebrowser smtube wcgbrowser-git netsurf palemoon-bin 
## Några andra webbrowser
## trizen -S yandex-browser-beta slimjet brave iridium inox-bin ##  cliqz icecat ungoogled-chromium
##
###############################################################################################################################################################
##
## Console
## trizen -S w3m lynx links elinks
##
###############################################################################################################################################################
##
## Gecko-based
## trizen -S firefox seamonkey
##
###############################################################################################################################################################
##
## Firefox spin-offs
## Cliqz — Firefox-based privacy aware web browser.
## Cyberfox — Fast and privacy oriented fork of Mozilla Firefox.
## Waterfox — Optimized fork of Mozilla Firefox, without data collection and allowing unsigned extensions and NPAPI plugins.
## GNU IceCat — A customized build of Firefox ESR distributed by the GNU Project, stripped of non-free components and with additional privacy extensions. Release cycle may be delayed compared to Mozilla Firefox.
##
## trizen -S cliqz cyberfox-bin waterfox-bin icecast OR icecast-bin
##
###############################################################################################################################################################
##
## Blink-based
## Chromium — Web browser developed by Google, the open source project behind Google Chrome.
## trizen -S chromium
## 
## Chromium spin-offs
## Google Chrome — Proprietary web browser developed by Google.
## Inox — A privacy-focused patchset for Chromium, which disables Google services, proprietary features, prevents "calling home" and unhides all extensions.
## Iridium — A privacy-focused patchset for Chromium. See differences from Chromium.
## Opera — Proprietary browser developed by Opera Software.
## Slimjet — Fast, smart and powerful proprietary browser based on Chromium.
## Ungoogled Chromium — Modifications to Google Chromium for removing Google integration and enhancing privacy, control, and transparency
## Vivaldi — An advanced proprietary browser made with the power user in mind.
## Yandex Browser — Proprietary browser that combines a minimal design with sophisticated technology to make the web faster, safer, and easier.
##
## trizen -S google-chrome inox or inox-bin iridium opera slimjet ungoogled-chromium vivaldiyandex-browser-beta
##
###############################################################################################################################################################
##
## Browsers based on qt5-webengine
## 
## Crusta — Blazingly fast full feature web browser with unique features.
## Dooble — Colorful Web browser.
## Eric — QtWebEngine-based HTML browser, part of the eric6 development toolset, can be launched with the eric6_browser command.
## Falkon — Web browser based on QtWebEngine, written in Qt framework.
## Konqueror — Web browser based on Qt toolkit and Qt WebEngine (or KHTML layout engine), part of kdebase.
## Liri Browser — A minimalistic material design web browser written for Liri.
## Qt WebBrowser — Browser for embedded devices developed using the capabilities of Qt and Qt WebEngine.
## qutebrowser — A keyboard-driven, vim-like browser based on PyQt5 and QtWebEngine.
##
## trizen -S crusta dooble eric falkon konqueror liri-browser-git qtwebbrowser qutebrowser
##
###############################################################################################################################################################
##
## Browsers based on electron/muon
## 
## Beaker — Peer-to-peer web browser with tools to create and host websites. Based on the Electron platform.
## Brave — Web browser that blocks ads and trackers by default. Based on the Muon platform (fork of Electron).
## Min — A smarter, faster web browser based on the Electron platform.
##
## trizen -S beaker-browser brave OR brave-bin min
##
###############################################################################################################################################################
##
## Browsers based on webkit2gtk
## 
## Eolie — Simple web browser for GNOME.
## GNOME Web — Browser which uses the WebKitGTK+ rendering engine, part of gnome.
## Lariza — A simple, experimental web browser using GTK+ 3, GLib and WebKit2GTK+.
## Luakit — Fast, small, webkit based browser framework extensible by Lua.
## Midori — Lightweight web browser based on GTK+ and WebKit.
## Poseidon — Fast, minimal and lightweight browser, written in Python.
## surf — Lightweight WebKit-based browser, which follows the suckless ideology (basically, the browser itself is a single C source file).
## Surfer — Simple keyboard based web browser, written in C.
## Uzbl — Group of web interface tools which adhere to the Unix philosophy.
## Vimb — A Vim-like web browser that is inspired by Pentadactyl and Vimprobable.
##
## trizen -S eolielariza luakit poseidon surf surfer uzbl-browser vimb
## Redan installerade, se ovan: epiphany midori
##
###############################################################################################################################################################
##
## Browsers based on qt5-webkit
##
## Eric — QtWebKit-based HTML browser, part of the eric6 development toolset, can be launched with the eric6_webbrowser command.
## OSPKit — Webkit based html browser for printing.
## Otter Browser — Browser aiming to recreate classic Opera (12.x) UI using Qt5.
## qutebrowser — A keyboard-driven, vim-like browser based on PyQt5 with QtWebKit as an available backend.
## smtube — Application that allows to browse, search and play YouTube videos.
## WCGBrowser — A web browser for kiosk systems.
##
## trizen -S eric ospkit-git otter-browser qutebrowser smtube wcgbrowser-git
##
###############################################################################################################################################################
##
## Vi-like web browsers
##
## Luakit — Fast, small, webkit based browser framework extensible by Lua.
## Vimb — A Vim-like web browser that is inspired by Pentadactyl and Vimprobable.
## qutebrowser — A keyboard-driven, vim-like browser based on PyQt5 and QtWebEngine.
##
## trizen -S luakit vimb qutebrowser
##
###############################################################################################################################################################
##
## Other
##
## Dillo — Small, fast graphical web browser built on FLTK. Uses its own layout engine.
## Links — Graphics and text mode web browser. Includes a graphical X-window/framebuffer version with CSS, image rendering, pull-down menus. It can be launched with the xlinks -g command.
## NetSurf — Featherweight browser written in C, notable for its slowly developing JavaScript support and fast rendering through its own layout engine.
## Pale Moon — A Firefox fork focussing on speed, with a pre-Firefox 29 interface. Uses Goanna layout engine, a fork of Gecko. Firefox add-ons may not be compatible. [1] Without support for newer Firefox features such as cache2, e10s, and OTMC.
##
## trizen -S dillo links netsurf palemoon or palemoon-bin
##









