#/bin/bash
# First obtain a location code from: https://weather.codes/search/

# Insert your location code. For example 
# SWXX0033	Sundsvall, Sweden
# SWXX0007	Gothenburg, Sweden

export INTERVAL=15
weather=1
URL_SDL='https://www.accuweather.com/sv/se/sundsvall/315848/weather-forecast/315848'
URL_GBG='https://www.accuweather.com/sv/se/goteborg/315909/weather-forecast/315909'

while [ true ]
    do
    	clear
#	echo $(date "+%Y-%m-%d %H:%M")
	echo
	if [ $weather -eq 1 ]
	then
		curl -s http://wttr.in/sundsvall 
		echo
		sh sunrise-sunset.sh SWXX0033
		echo
		wget -q -O- "$URL_SDL" | awk -F\' '/acm_RecentLocationsCarousel\.push/{print $2": "$16", "$12"°" }'| head -1
        inxi -xxxW Sundsvall
#		sh sunrise-sunset.sh SWXX0033
    	sleep ${INTERVAL}
		weather=0
	else
		curl -s http://wttr.in/"goteborg" # curl -s wttr.in/@goteborg.se
		echo
		sh sunrise-sunset.sh SWXX0007
		echo
		# wget -q -O- "$URL_GBG" | awk -F\' '/acm_RecentLocationsCarousel\.push/{print $2": "$16", "$12"°" }'| head -1
      	inxi -xxxW Göteborg
		sleep ${INTERVAL}
		weather=1
	fi
	echo
    done

