#!/bin/bash
clear

ping -c 3 8.8.8.8
echo

ping -c 3 www.google.com
echo
