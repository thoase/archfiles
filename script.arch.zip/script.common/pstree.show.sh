#!/bin/bash

## info från https://www.cyberciti.biz/tips/top-linux-monitoring-tools.html

clear
echo
pstree > pstree.show.txt

nano pstree.show.txt
