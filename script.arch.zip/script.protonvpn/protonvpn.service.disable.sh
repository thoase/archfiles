#!/bin/bash

echo

echo "Disable av protonvpn.service"
sudo systemctl disable openvpn-client@protonvpn.service

echo

